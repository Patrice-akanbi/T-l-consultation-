<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\ConsultationController;
use App\Http\Controllers\PrescriptionController;
use App\Http\Controllers\RappelController;
use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UtilisateurController;
use App\Http\Controllers\SmsController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::get('/patients/create', [PatientController::class, 'create'])->middleware('role:agent_sante');
Route::post('/patients', [PatientController::class, 'store'])->middleware('role:agent_sante');
Route::get('/patients', [PatientController::class, 'index'])->middleware('role:agent_sante,medecin,administrateur');
Route::get('/patients/{id}', [PatientController::class, 'show'])->middleware('role:agent_sante,medecin,administrateur');

Route::get('/consultations/create', [ConsultationController::class, 'create'])->middleware('role:agent_sante');
Route::post('/consultations', [ConsultationController::class, 'store'])->middleware('role:agent_sante');
Route::get('/consultations/en-attente', [ConsultationController::class, 'enAttente'])->middleware('role:medecin');
Route::post('/consultations/{id}/prendre-en-charge', [ConsultationController::class, 'prendreEnCharge'])->middleware('role:medecin');

Route::get('/prescriptions/create', [PrescriptionController::class, 'create'])->middleware('role:medecin');
Route::post('/prescriptions', [PrescriptionController::class, 'store'])->middleware('role:medecin');

Route::get('/rappels/create', [RappelController::class, 'create'])->middleware('role:agent_sante');
Route::post('/rappels', [RappelController::class, 'store'])->middleware('role:agent_sante');
Route::get('/rappels', [RappelController::class, 'index'])->middleware('role:agent_sante,medecin,administrateur');

Route::get('/statistiques', [DashboardController::class, 'index'])->middleware('role:administrateur');

Route::get('/utilisateurs/agent/create', [UtilisateurController::class, 'createAgent'])->middleware('role:administrateur');
Route::post('/utilisateurs/agent', [UtilisateurController::class, 'storeAgent'])->middleware('role:administrateur');
Route::get('/utilisateurs/medecin/create', [UtilisateurController::class, 'createMedecin'])->middleware('role:administrateur');
Route::post('/utilisateurs/medecin', [UtilisateurController::class, 'storeMedecin'])->middleware('role:administrateur');

Route::get('/sms/create', [SmsController::class, 'create'])->middleware('role:agent_sante');
Route::post('/sms/simuler', [SmsController::class, 'simuler'])->middleware('role:agent_sante');
Route::delete('/patients/{id}', [PatientController::class, 'destroy'])->middleware('role:agent_sante,administrateur');
Route::get('/patients/{id}/edit', [PatientController::class, 'edit'])->middleware('role:agent_sante,administrateur');
Route::put('/patients/{id}', [PatientController::class, 'update'])->middleware('role:agent_sante,administrateur');
Route::patch('/rappels/{id}/statut', [RappelController::class, 'updateStatut'])->middleware('role:agent_sante,medecin,administrateur');
Route::delete('/rappels/{id}', [RappelController::class, 'destroy'])->middleware('role:agent_sante,administrateur');
Route::delete('/consultations/{id}', [ConsultationController::class, 'destroy'])->middleware('role:agent_sante,administrateur');
Route::get('/patients/export/excel', [PatientController::class, 'exportExcel'])->middleware('role:agent_sante,medecin,administrateur');
Route::get('/statistiques/export/pdf', [DashboardController::class, 'exportPdf'])->middleware('role:administrateur');
Route::get('/patients/{id}/export/pdf', [PatientController::class, 'exportPdf'])->middleware('role:agent_sante,medecin,administrateur');

require __DIR__.'/auth.php';