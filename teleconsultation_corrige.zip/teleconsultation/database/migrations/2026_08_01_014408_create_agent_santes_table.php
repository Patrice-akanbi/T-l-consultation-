<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('agent_santes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('utilisateur_id')->constrained('utilisateurs')->onDelete('cascade');
            $table->string('village_affectation');
            $table->string('zone_couverte');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('agent_santes');
    }
};
