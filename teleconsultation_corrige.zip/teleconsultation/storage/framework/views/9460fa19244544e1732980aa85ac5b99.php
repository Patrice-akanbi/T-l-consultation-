<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des patients</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background: #1F4E79; color: white; }
        tr:nth-child(even) { background: #f2f2f2; }
        a.bouton { display: inline-block; margin-top: 15px; padding: 8px 16px; background: #1F4E79; color: white; text-decoration: none; }
        a { color: #1F4E79; }
        form.delete-form { display: inline; }
        .btn-delete { background: #c0392b; color: white; border: none; padding: 4px 10px; border-radius: 3px; cursor: pointer; font-size: 0.85em; }
    </style>
</head>
<body>
    <h1>Liste des patients</h1>

    <a class="bouton" href="/patients/create">+ Ajouter un patient</a>

    <a class="bouton" href="/patients/export/excel" style="background:#2f855a;">Exporter en Excel</a>

    <table>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Téléphone</th>
                <th>Âge</th>
                <th>Village</th>
                <th>Sexe</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="/patients/<?php echo e($patient->id); ?>"><?php echo e($patient->utilisateur->nom); ?></a></td>
                    <td><?php echo e($patient->utilisateur->prenom); ?></td>
                    <td><?php echo e($patient->utilisateur->telephone); ?></td>
                    <td><?php echo e($patient->age); ?></td>
                    <td><?php echo e($patient->village); ?></td>
                    <td><?php echo e($patient->sexe); ?></td>
                    <td>
                        <form class="delete-form" method="POST" action="/patients/<?php echo e($patient->id); ?>" onsubmit="return confirm('Supprimer ce patient et toutes ses données liées ?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn-delete">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/patients/index.blade.php ENDPATH**/ ?>