<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Consultations en attente</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background: #1F4E79; color: white; }
        tr:nth-child(even) { background: #f2f2f2; }
        .succes { background: #d4edda; padding: 10px; margin-bottom: 15px; color: #155724; }
        button { padding: 6px 12px; background: #1F4E79; color: white; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Consultations en attente</h1>

    <?php if(session('succes')): ?>
        <div class="succes"><?php echo e(session('succes')); ?></div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>Patient</th>
                <th>Date</th>
                <th>Symptômes</th>
                <th>Température</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($consultation->patient->utilisateur->nom); ?> <?php echo e($consultation->patient->utilisateur->prenom); ?></td>
                    <td><?php echo e($consultation->date); ?></td>
                    <td><?php echo e($consultation->constantesSante->first()->symptomes ?? '—'); ?></td>
                    <td><?php echo e($consultation->constantesSante->first()->temperature ?? '—'); ?></td>
                    <td>
                        <form method="POST" action="/consultations/<?php echo e($consultation->id); ?>/prendre-en-charge">
                            <?php echo csrf_field(); ?>
                            <button type="submit">Prendre en charge</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5">Aucune consultation en attente.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/consultations/en_attente.blade.php ENDPATH**/ ?>