<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
        h1 { color: #1F4E79; font-size: 18px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ccc; padding: 6px; text-align: left; }
        th { background: #1F4E79; color: white; }
        .stats-table td.label { font-weight: bold; width: 60%; }
        .date { font-size: 10px; color: #666; margin-bottom: 15px; }
    </style>
</head>
<body>
    <h1>Tableau de bord statistique — Plateforme de téléconsultation</h1>
    <div class="date">Généré le <?php echo e(now()->format('d/m/Y à H:i')); ?></div>

    <table class="stats-table">
        <tr><td class="label">Patients enregistrés</td><td><?php echo e($stats['total_patients']); ?></td></tr>
        <tr><td class="label">Consultations totales</td><td><?php echo e($stats['total_consultations']); ?></td></tr>
        <tr><td class="label">Consultations en attente</td><td><?php echo e($stats['consultations_en_attente']); ?></td></tr>
        <tr><td class="label">Consultations en cours</td><td><?php echo e($stats['consultations_en_cours']); ?></td></tr>
        <tr><td class="label">Consultations terminées</td><td><?php echo e($stats['consultations_terminees']); ?></td></tr>
        <tr><td class="label">Agents de santé</td><td><?php echo e($stats['total_agents']); ?></td></tr>
        <tr><td class="label">Médecins</td><td><?php echo e($stats['total_medecins']); ?></td></tr>
    </table>

    <h2>Répartition des patients par village</h2>
    <table>
        <thead>
            <tr><th>Village</th><th>Nombre de patients</th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $parVillage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ligne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr><td><?php echo e($ligne->village); ?></td><td><?php echo e($ligne->total); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="2">Aucune donnée.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/dashboard-pdf.blade.php ENDPATH**/ ?>