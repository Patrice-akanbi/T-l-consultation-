<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Simulation SMS/USSD</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 550px; margin: 40px auto; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input, textarea { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; font-family: monospace; }
        button { margin-top: 20px; padding: 10px 20px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        .succes { background: #d4edda; padding: 10px; margin-bottom: 15px; color: #155724; }
        .erreur { background: #f8d7da; padding: 10px; margin-bottom: 15px; color: #721c24; }
        .aide { background: #f2f2f2; padding: 12px; margin-top: 20px; font-size: 0.9em; }
        .aide code { background: #ddd; padding: 2px 5px; }
    </style>
</head>
<body>
    <h1>Simulation d'un SMS entrant</h1>
    <p>Cette page simule la réception d'un message via une passerelle SMS/USSD, pour les zones à connectivité limitée.</p>

    <?php if(session('succes')): ?>
        <div class="succes"><?php echo e(session('succes')); ?></div>
    <?php endif; ?>

    <?php if(session('erreur')): ?>
        <div class="erreur"><?php echo e(session('erreur')); ?></div>
    <?php endif; ?>

    <form method="POST" action="/sms/simuler">
        <?php echo csrf_field(); ?>

        <label>Message SMS simulé</label>
        <textarea name="message" rows="2" placeholder="CONS 2 38.5 fievre et toux"></textarea>

        <button type="submit">Envoyer le SMS simulé</button>
    </form>

    <div class="aide">
        <strong>Format attendu :</strong> <code>CONS &lt;id_patient&gt; &lt;temperature&gt; &lt;symptomes&gt;</code><br><br>
        <strong>Patients disponibles :</strong><br>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            id <?php echo e($patient->id); ?> — <?php echo e($patient->utilisateur->nom); ?> <?php echo e($patient->utilisateur->prenom); ?><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/sms/create.blade.php ENDPATH**/ ?>