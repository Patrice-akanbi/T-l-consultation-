<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dossier patient</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 750px; margin: 40px auto; }
        h1 { color: #1F4E79; }
        .fiche { background: #f2f2f2; padding: 15px; border-radius: 4px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background: #1F4E79; color: white; }
        .statut { padding: 3px 8px; border-radius: 3px; font-size: 0.85em; }
        .en_attente { background: #fff3cd; }
        .terminee { background: #d4edda; }
        a.retour { display: inline-block; margin-bottom: 15px; color: #1F4E79; }
        .actions { margin: 10px 0 20px; display: flex; gap: 10px; align-items: center; }
        .actions a, .actions button {
            display: inline-block; padding: 6px 14px; border-radius: 4px; text-decoration: none;
            font-size: 0.9em; border: none; cursor: pointer;
        }
        .btn-modifier { background: #1F4E79; color: white; }
        .btn-export { background: #2f855a; color: white; }
        .btn-delete { background: #c0392b; color: white; }
        .btn-delete-consult { background: #c0392b; color: white; border: none; padding: 4px 10px; border-radius: 3px; cursor: pointer; font-size: 0.85em; }
    </style>
</head>
<body>
    <a class="retour" href="/patients">&larr; Retour à la liste</a>

    <h1><?php echo e($patient->utilisateur->nom); ?> <?php echo e($patient->utilisateur->prenom); ?></h1>

    <div class="actions">
        <a class="btn-modifier" href="/patients/<?php echo e($patient->id); ?>/edit">Modifier ce patient</a>
        <a class="btn-export" href="/patients/<?php echo e($patient->id); ?>/export/pdf">Exporter en PDF</a>
        <form method="POST" action="/patients/<?php echo e($patient->id); ?>" onsubmit="return confirm('Supprimer ce patient et toutes ses données liées ?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn-delete">Supprimer</button>
        </form>
    </div>

    <div class="fiche">
        <strong>Téléphone :</strong> <?php echo e($patient->utilisateur->telephone); ?><br>
        <strong>Âge :</strong> <?php echo e($patient->age); ?> ans<br>
        <strong>Village :</strong> <?php echo e($patient->village); ?><br>
        <strong>Sexe :</strong> <?php echo e($patient->sexe); ?>

    </div>

    <?php if($patient->dossierMedical): ?>
        <h2>Dossier médical</h2>
        <div class="fiche">
            <strong>Antécédents :</strong> <?php echo e($patient->dossierMedical->antecedent ?? 'Aucun renseigné'); ?><br>
            <strong>Historique :</strong> <?php echo e($patient->dossierMedical->historique ?? 'Aucun renseigné'); ?>

        </div>
    <?php endif; ?>

    <h2>Historique des consultations</h2>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Mode</th>
                <th>Statut</th>
                <th>Prescription / Orientation</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $patient->consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($consultation->date); ?></td>
                    <td><?php echo e($consultation->mode); ?></td>
                    <td><span class="statut <?php echo e($consultation->statut); ?>"><?php echo e($consultation->statut); ?></span></td>
                    <td>
                        <?php if($consultation->prescription): ?>
                            <?php echo e($consultation->prescription->medicaments ?? $consultation->prescription->orientation ?? '—'); ?>

                        <?php else: ?>
                            En attente
                        <?php endif; ?>
                    </td>
                    <td>
                        <form method="POST" action="/consultations/<?php echo e($consultation->id); ?>" onsubmit="return confirm('Supprimer cette consultation et ses données liées (constantes, prescription) ?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn-delete-consult">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5">Aucune consultation enregistrée.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/patients/show.blade.php ENDPATH**/ ?>