<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
        h1 { color: #1F4E79; font-size: 18px; }
        h2 { color: #1F4E79; font-size: 14px; margin-top: 20px; }
        .fiche td { padding: 4px 8px; }
        .fiche td.label { font-weight: bold; width: 150px; }
        table.historique { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table.historique th, table.historique td { border: 1px solid #ccc; padding: 6px; text-align: left; }
        table.historique th { background: #1F4E79; color: white; }
        .date { font-size: 10px; color: #666; margin-bottom: 15px; }
    </style>
</head>
<body>
    <h1>Dossier patient — <?php echo e($patient->utilisateur->nom); ?> <?php echo e($patient->utilisateur->prenom); ?></h1>
    <div class="date">Généré le <?php echo e(now()->format('d/m/Y à H:i')); ?></div>

    <table class="fiche">
        <tr><td class="label">Téléphone</td><td><?php echo e($patient->utilisateur->telephone); ?></td></tr>
        <tr><td class="label">Âge</td><td><?php echo e($patient->age); ?> ans</td></tr>
        <tr><td class="label">Village</td><td><?php echo e($patient->village); ?></td></tr>
        <tr><td class="label">Sexe</td><td><?php echo e($patient->sexe); ?></td></tr>
    </table>

    <?php if($patient->dossierMedical): ?>
        <h2>Dossier médical</h2>
        <table class="fiche">
            <tr><td class="label">Antécédents</td><td><?php echo e($patient->dossierMedical->antecedent ?? 'Aucun renseigné'); ?></td></tr>
            <tr><td class="label">Historique</td><td><?php echo e($patient->dossierMedical->historique ?? 'Aucun renseigné'); ?></td></tr>
        </table>
    <?php endif; ?>

    <h2>Historique des consultations</h2>
    <table class="historique">
        <thead>
            <tr>
                <th>Date</th>
                <th>Mode</th>
                <th>Statut</th>
                <th>Prescription / Orientation</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $patient->consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($consultation->date); ?></td>
                    <td><?php echo e($consultation->mode); ?></td>
                    <td><?php echo e($consultation->statut); ?></td>
                    <td>
                        <?php if($consultation->prescription): ?>
                            <?php echo e($consultation->prescription->medicaments ?? $consultation->prescription->orientation ?? '—'); ?>

                        <?php else: ?>
                            En attente
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4">Aucune consultation enregistrée.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/patients/pdf.blade.php ENDPATH**/ ?>