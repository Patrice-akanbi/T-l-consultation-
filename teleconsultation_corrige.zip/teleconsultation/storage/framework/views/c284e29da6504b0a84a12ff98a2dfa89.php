<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un médecin</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 40px auto; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 20px; padding: 10px 20px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        .succes { background: #d4edda; padding: 10px; margin-bottom: 15px; color: #155724; }
        .erreur { background: #f8d7da; padding: 10px; margin-bottom: 15px; color: #721c24; }
    </style>
</head>
<body>
    <h1>Ajouter un médecin</h1>

    <?php if(session('succes')): ?>
        <div class="succes"><?php echo e(session('succes')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="erreur">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="/utilisateurs/medecin">
        <?php echo csrf_field(); ?>

        <label>Nom</label>
        <input type="text" name="nom" value="<?php echo e(old('nom')); ?>">

        <label>Prénom</label>
        <input type="text" name="prenom" value="<?php echo e(old('prenom')); ?>">

        <label>Téléphone</label>
        <input type="text" name="telephone" value="<?php echo e(old('telephone')); ?>">

        <label>Mot de passe</label>
        <input type="password" name="mot_de_passe">

        <label>Spécialité</label>
        <input type="text" name="specialite" value="<?php echo e(old('specialite')); ?>">

        <label>Matricule</label>
        <input type="text" name="matricule" value="<?php echo e(old('matricule')); ?>">

        <button type="submit">Créer le médecin</button>
    </form>
</body>
</html><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/utilisateurs/create-medecin.blade.php ENDPATH**/ ?>