<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Saisir les constantes de santé</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 40px auto; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 20px; padding: 10px 20px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        .succes { background: #d4edda; padding: 10px; margin-bottom: 15px; color: #155724; }
        .erreur { background: #f8d7da; padding: 10px; margin-bottom: 15px; color: #721c24; }
    </style>
</head>
<body>
    <h1>Saisir les constantes de santé</h1>

    <?php if(session('succes')): ?>
        <div class="succes"><?php echo e(session('succes')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="erreur">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="/consultations">
        <?php echo csrf_field(); ?>

        <label>Patient</label>
        <select name="patient_id">
            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($patient->id); ?>">
                    <?php echo e($patient->utilisateur->nom); ?> <?php echo e($patient->utilisateur->prenom); ?> (<?php echo e($patient->village); ?>)
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label>Température (°C)</label>
        <input type="number" step="0.1" name="temperature">

        <label>Tension</label>
        <input type="text" name="tension" placeholder="ex: 12/8">

        <label>Symptômes</label>
        <textarea name="symptomes" rows="3"></textarea>

        <label>Poids (kg)</label>
        <input type="number" step="0.01" name="poids">

        <button type="submit">Enregistrer et créer la consultation</button>
    </form>
</body>
</html><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/consultations/create.blade.php ENDPATH**/ ?>