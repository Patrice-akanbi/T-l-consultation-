<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Émettre une prescription</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 40px auto; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 20px; padding: 10px 20px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        .succes { background: #d4edda; padding: 10px; margin-bottom: 15px; color: #155724; }
        .erreur { background: #f8d7da; padding: 10px; margin-bottom: 15px; color: #721c24; }
    </style>
</head>
<body>
    <h1>Émettre une prescription</h1>

    <?php if(session('succes')): ?>
        <div class="succes"><?php echo e(session('succes')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="erreur">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="/prescriptions">
        <?php echo csrf_field(); ?>

        <label>Consultation</label>
        <select name="consultation_id">
            <?php $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($consultation->id); ?>">
                    <?php echo e($consultation->patient->utilisateur->nom); ?> <?php echo e($consultation->patient->utilisateur->prenom); ?>

                    — <?php echo e($consultation->date); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label>Médicaments</label>
        <textarea name="medicaments" rows="2"></textarea>

        <label>Posologie</label>
        <textarea name="posologie" rows="2"></textarea>

        <label>Orientation (si besoin d'un centre de santé)</label>
        <textarea name="orientation" rows="2"></textarea>

        <button type="submit">Émettre la prescription</button>
    </form>
</body>
</html><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/prescriptions/create.blade.php ENDPATH**/ ?>