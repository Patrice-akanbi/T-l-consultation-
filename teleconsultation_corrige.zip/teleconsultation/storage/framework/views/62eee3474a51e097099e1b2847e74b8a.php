<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier un patient</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 40px auto; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 20px; padding: 10px 20px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        .erreur { background: #f8d7da; padding: 10px; margin-bottom: 15px; color: #721c24; }
    </style>
</head>
<body>
    <h1>Modifier le patient</h1>

    <?php if($errors->any()): ?>
        <div class="erreur">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="/patients/<?php echo e($patient->id); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label>Nom</label>
        <input type="text" name="nom" value="<?php echo e(old('nom', $patient->utilisateur->nom)); ?>">

        <label>Prénom</label>
        <input type="text" name="prenom" value="<?php echo e(old('prenom', $patient->utilisateur->prenom)); ?>">

        <label>Téléphone</label>
        <input type="text" name="telephone" value="<?php echo e(old('telephone', $patient->utilisateur->telephone)); ?>">

        <label>Âge</label>
        <input type="number" name="age" value="<?php echo e(old('age', $patient->age)); ?>">

        <label>Village</label>
        <input type="text" name="village" value="<?php echo e(old('village', $patient->village)); ?>">

        <label>Sexe</label>
        <select name="sexe">
            <option value="M" <?php echo e($patient->sexe === 'M' ? 'selected' : ''); ?>>Masculin</option>
            <option value="F" <?php echo e($patient->sexe === 'F' ? 'selected' : ''); ?>>Féminin</option>
        </select>

        <button type="submit">Enregistrer les modifications</button>
    </form>
</body>
</html><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/patients/edit.blade.php ENDPATH**/ ?>