<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Tableau de bord
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <p class="mb-6">Vous êtes connecté en tant que <strong><?php echo e(ucfirst(auth()->user()->type_utilisateur)); ?></strong>.</p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                    <?php if(auth()->user()->type_utilisateur === 'agent_sante'): ?>
                        <a href="/patients/create" class="block p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200">
                            <strong>Enregistrer un patient</strong>
                            <p class="text-sm text-gray-600">Créer un nouveau dossier patient</p>
                        </a>
                        <a href="/patients" class="block p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200">
                            <strong>Liste des patients</strong>
                            <p class="text-sm text-gray-600">Consulter les patients enregistrés</p>
                        </a>
                        <a href="/consultations/create" class="block p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200">
                            <strong>Saisir les constantes de santé</strong>
                            <p class="text-sm text-gray-600">Créer une consultation</p>
                        </a>
                        <a href="/rappels/create" class="block p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200">
                            <strong>Créer un rappel</strong>
                            <p class="text-sm text-gray-600">Programmer un rappel pour un patient</p>
                        </a>
                        <a href="/rappels" class="block p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200">
                            <strong>Liste des rappels</strong>
                            <p class="text-sm text-gray-600">Voir tous les rappels créés</p>
                        </a>
                        <a href="/sms/create" class="block p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200">
                            <strong>Simulation SMS/USSD</strong>
                            <p class="text-sm text-gray-600">Mode dégradé, zones à faible connexion</p>
                        </a>
                    <?php endif; ?>

                    <?php if(auth()->user()->type_utilisateur === 'medecin'): ?>
                        <a href="/consultations/en-attente" class="block p-4 bg-green-50 hover:bg-green-100 rounded-lg border border-green-200">
                            <strong>Consultations en attente</strong>
                            <p class="text-sm text-gray-600">Prendre en charge une téléconsultation</p>
                        </a>
                        <a href="/prescriptions/create" class="block p-4 bg-green-50 hover:bg-green-100 rounded-lg border border-green-200">
                            <strong>Émettre une prescription</strong>
                            <p class="text-sm text-gray-600">Rédiger un compte rendu médical</p>
                        </a>
                        <a href="/patients" class="block p-4 bg-green-50 hover:bg-green-100 rounded-lg border border-green-200">
                            <strong>Liste des patients</strong>
                            <p class="text-sm text-gray-600">Consulter les dossiers patients</p>
                        </a>
                    <?php endif; ?>

                    <?php if(auth()->user()->type_utilisateur === 'administrateur'): ?>
                        <a href="/utilisateurs/agent/create" class="block p-4 bg-amber-50 hover:bg-amber-100 rounded-lg border border-amber-200">
                            <strong>Ajouter un agent de santé</strong>
                            <p class="text-sm text-gray-600">Créer un nouveau compte ASC</p>
                        </a>
                        <a href="/utilisateurs/medecin/create" class="block p-4 bg-amber-50 hover:bg-amber-100 rounded-lg border border-amber-200">
                            <strong>Ajouter un médecin</strong>
                            <p class="text-sm text-gray-600">Créer un nouveau compte médecin</p>
                        </a>
                        <a href="/statistiques" class="block p-4 bg-amber-50 hover:bg-amber-100 rounded-lg border border-amber-200">
                            <strong>Tableau de bord statistique</strong>
                            <p class="text-sm text-gray-600">Indicateurs et répartition par village</p>
                        </a>
                        <a href="/patients" class="block p-4 bg-amber-50 hover:bg-amber-100 rounded-lg border border-amber-200">
                            <strong>Liste des patients</strong>
                            <p class="text-sm text-gray-600">Consulter les dossiers patients</p>
                        </a>
                        <a href="/rappels" class="block p-4 bg-amber-50 hover:bg-amber-100 rounded-lg border border-amber-200">
                            <strong>Liste des rappels</strong>
                            <p class="text-sm text-gray-600">Voir tous les rappels créés</p>
                        </a>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\teleconsultation\resources\views/dashboard.blade.php ENDPATH**/ ?>