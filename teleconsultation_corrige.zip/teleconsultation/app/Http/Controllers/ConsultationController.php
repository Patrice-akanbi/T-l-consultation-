<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use App\Models\Consultation;
use App\Models\ConstanteSante;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ConsultationController extends Controller
{
    public function create()
    {
        $patients = Patient::with('utilisateur')->get();
        return view('consultations.create', ['patients' => $patients]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'temperature' => 'nullable|numeric',
            'tension' => 'nullable|string',
            'symptomes' => 'nullable|string',
            'poids' => 'nullable|numeric',
        ]);

        $consultation = Consultation::create([
            'patient_id' => $request->patient_id,
            'agent_sante_id' => 1, // temporaire, en attendant l'authentification
            'date' => now()->toDateString(),
            'heure' => now()->toTimeString(),
            'mode' => 'connecte',
            'statut' => 'en_attente',
        ]);

        ConstanteSante::create([
            'consultation_id' => $consultation->id,
            'temperature' => $request->temperature,
            'tension' => $request->tension,
            'symptomes' => $request->symptomes,
            'poids' => $request->poids,
        ]);

        return redirect('/consultations/create')->with('succes', 'Constantes de santé enregistrées, consultation créée !');
    }

    public function enAttente()
    {
        $consultations = Consultation::with('patient.utilisateur', 'constantesSante')
            ->where('statut', 'en_attente')
            ->whereNull('medecin_id')
            ->get();

        return view('consultations.en_attente', ['consultations' => $consultations]);
    }

    public function prendreEnCharge($id)
    {
        $medecin = Auth::user()->medecin;

        $consultation = Consultation::findOrFail($id);
        $consultation->update([
            'medecin_id' => $medecin->id,
            'statut' => 'en_cours',
        ]);

        return redirect('/consultations/en-attente')->with('succes', 'Consultation prise en charge !');
    }

    public function destroy($id)
    {
        Consultation::findOrFail($id)->delete();
        return redirect('/patients')->with('succes', 'Consultation supprimée avec succès.');
    }
    
}