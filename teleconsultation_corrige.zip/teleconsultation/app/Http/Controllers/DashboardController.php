<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use App\Models\Consultation;
use App\Models\AgentSante;
use App\Models\Medecin;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_patients' => Patient::count(),
            'total_consultations' => Consultation::count(),
            'consultations_en_attente' => Consultation::where('statut', 'en_attente')->count(),
            'consultations_en_cours' => Consultation::where('statut', 'en_cours')->count(),
            'consultations_terminees' => Consultation::where('statut', 'terminee')->count(),
            'total_agents' => AgentSante::count(),
            'total_medecins' => Medecin::count(),
        ];

        $parVillage = Patient::selectRaw('village, count(*) as total')
            ->groupBy('village')
            ->orderByDesc('total')
            ->get();

        // Consultations par mode (connecte / degrade)
        $parMode = Consultation::selectRaw('mode, count(*) as total')
            ->groupBy('mode')
            ->get();

        // Evolution des consultations sur les 6 derniers mois
        $parMois = Consultation::selectRaw("DATE_FORMAT(date, '%Y-%m') as mois, count(*) as total")
            ->where('date', '>=', now()->subMonths(6)->startOfMonth())
            ->groupBy('mois')
            ->orderBy('mois')
            ->get();

        return view('dashboard-stats', [
            'stats' => $stats,
            'parVillage' => $parVillage,
            'parMode' => $parMode,
            'parMois' => $parMois,
        ]);
    }

    public function exportPdf()
    {
        $stats = [
            'total_patients' => Patient::count(),
            'total_consultations' => Consultation::count(),
            'consultations_en_attente' => Consultation::where('statut', 'en_attente')->count(),
            'consultations_en_cours' => Consultation::where('statut', 'en_cours')->count(),
            'consultations_terminees' => Consultation::where('statut', 'terminee')->count(),
            'total_agents' => AgentSante::count(),
            'total_medecins' => Medecin::count(),
        ];

        $parVillage = Patient::selectRaw('village, count(*) as total')
            ->groupBy('village')
            ->orderByDesc('total')
            ->get();

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('dashboard-pdf', [
            'stats' => $stats,
            'parVillage' => $parVillage,
        ]);

        return $pdf->download('statistiques.pdf');
    }
}