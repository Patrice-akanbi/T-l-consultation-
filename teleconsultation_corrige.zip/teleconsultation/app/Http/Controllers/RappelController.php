<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use App\Models\Rappel;
use Illuminate\Http\Request;

class RappelController extends Controller
{
    public function create()
    {
        $patients = Patient::with('utilisateur')->get();
        return view('rappels.create', ['patients' => $patients]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'type' => 'required|string',
            'date_envoi' => 'required|date',
        ]);

        Rappel::create([
            'patient_id' => $request->patient_id,
            'type' => $request->type,
            'date_envoi' => $request->date_envoi,
            'statut' => 'non_envoye',
        ]);

        return redirect('/rappels')->with('succes', 'Rappel créé avec succès !');
    }

    public function index()
    {
        $rappels = Rappel::with('patient.utilisateur')->orderBy('date_envoi')->get();
        return view('rappels.index', ['rappels' => $rappels]);
    }

    public function updateStatut(Request $request, $id)
    {
        $request->validate([
            'statut' => 'required|in:non_envoye,envoye,lu',
        ]);

        $rappel = Rappel::findOrFail($id);
        $rappel->update(['statut' => $request->statut]);

        return redirect('/rappels')->with('succes', 'Statut du rappel mis à jour.');
    }

    public function destroy($id)
    {
        Rappel::findOrFail($id)->delete();
        return redirect('/rappels')->with('succes', 'Rappel supprimé avec succès.');
    }
}