<?php

namespace App\Http\Controllers;

use App\Models\Consultation;
use App\Models\Prescription;
use Illuminate\Http\Request;

class PrescriptionController extends Controller
{
    public function create()
    {
        $consultations = Consultation::with('patient.utilisateur')
            ->whereDoesntHave('prescription')
            ->get();

        return view('prescriptions.create', ['consultations' => $consultations]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'consultation_id' => 'required|exists:consultations,id',
            'medicaments' => 'nullable|string',
            'posologie' => 'nullable|string',
            'orientation' => 'nullable|string',
        ]);

        Prescription::create([
            'consultation_id' => $request->consultation_id,
            'medicaments' => $request->medicaments,
            'posologie' => $request->posologie,
            'orientation' => $request->orientation,
        ]);

        $consultation = Consultation::find($request->consultation_id);
        $consultation->update(['statut' => 'terminee']);

        return redirect('/prescriptions/create')->with('succes', 'Prescription émise avec succès !');
    }
}