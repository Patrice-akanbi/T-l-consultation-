<?php

namespace App\Http\Controllers;

use App\Models\Utilisateur;
use App\Models\AgentSante;
use App\Models\Medecin;
use Illuminate\Http\Request;

class UtilisateurController extends Controller
{
    public function createAgent()
    {
        return view('utilisateurs.create-agent');
    }

    public function storeAgent(Request $request)
    {
        $request->validate([
            'nom' => 'required|string',
            'prenom' => 'required|string',
            'telephone' => 'required|string|unique:utilisateurs,telephone',
            'mot_de_passe' => 'required|string|min:6',
            'village_affectation' => 'required|string',
            'zone_couverte' => 'required|string',
        ]);

        $utilisateur = Utilisateur::create([
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'telephone' => $request->telephone,
            'mot_de_passe' => bcrypt($request->mot_de_passe),
            'type_utilisateur' => 'agent_sante',
        ]);

        AgentSante::create([
            'utilisateur_id' => $utilisateur->id,
            'village_affectation' => $request->village_affectation,
            'zone_couverte' => $request->zone_couverte,
        ]);

        return redirect('/utilisateurs/agent/create')->with('succes', 'Agent de santé créé avec succès !');
    }

    public function createMedecin()
    {
        return view('utilisateurs.create-medecin');
    }

    public function storeMedecin(Request $request)
    {
        $request->validate([
            'nom' => 'required|string',
            'prenom' => 'required|string',
            'telephone' => 'required|string|unique:utilisateurs,telephone',
            'mot_de_passe' => 'required|string|min:6',
            'specialite' => 'required|string',
            'matricule' => 'required|string|unique:medecins,matricule',
        ]);

        $utilisateur = Utilisateur::create([
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'telephone' => $request->telephone,
            'mot_de_passe' => bcrypt($request->mot_de_passe),
            'type_utilisateur' => 'medecin',
        ]);

        Medecin::create([
            'utilisateur_id' => $utilisateur->id,
            'specialite' => $request->specialite,
            'matricule' => $request->matricule,
        ]);

        return redirect('/utilisateurs/medecin/create')->with('succes', 'Médecin créé avec succès !');
    }
}