<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use App\Models\Consultation;
use App\Models\ConstanteSante;
use Illuminate\Http\Request;

class SmsController extends Controller
{
    public function create()
    {
        $patients = Patient::with('utilisateur')->get();
        return view('sms.create', ['patients' => $patients]);
    }

    public function simuler(Request $request)
    {
        $request->validate([
            'message' => 'required|string',
        ]);

        // Format attendu simulé : "CONS <patient_id> <temperature> <symptomes>"
        // Exemple : "CONS 2 38.5 fievre et toux"
        $parties = explode(' ', $request->message, 4);

        if (count($parties) < 4 || strtoupper($parties[0]) !== 'CONS') {
            return redirect('/sms/create')->with('erreur', 'Format invalide. Utilisez : CONS <id_patient> <temperature> <symptomes>');
        }

        $patientId = $parties[1];
        $temperature = $parties[2];
        $symptomes = $parties[3];

        $patient = Patient::find($patientId);
        if (! $patient) {
            return redirect('/sms/create')->with('erreur', 'Patient introuvable pour cet identifiant.');
        }

        $consultation = Consultation::create([
            'patient_id' => $patient->id,
            'agent_sante_id' => 1,
            'date' => now()->toDateString(),
            'heure' => now()->toTimeString(),
            'mode' => 'degrade',
            'statut' => 'en_attente',
        ]);

        ConstanteSante::create([
            'consultation_id' => $consultation->id,
            'temperature' => $temperature,
            'symptomes' => $symptomes,
        ]);

        return redirect('/sms/create')->with('succes', "SMS simulé reçu et traité : consultation créée en mode dégradé pour {$patient->utilisateur->nom}.");
    }
}