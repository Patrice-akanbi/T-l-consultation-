<?php

namespace App\Http\Controllers;

use App\Models\Utilisateur;
use App\Models\Patient;
use Illuminate\Http\Request;

class PatientController extends Controller
{
    public function create()
    {
        return view('patients.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nom' => 'required|string',
            'prenom' => 'required|string',
            'telephone' => 'required|string|unique:utilisateurs,telephone',
            'mot_de_passe' => 'required|string|min:6',
            'age' => 'required|integer',
            'village' => 'required|string',
            'sexe' => 'required|string',
        ]);

        $utilisateur = Utilisateur::create([
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'telephone' => $request->telephone,
            'mot_de_passe' => bcrypt($request->mot_de_passe),
            'type_utilisateur' => 'patient',
        ]);

        Patient::create([
            'utilisateur_id' => $utilisateur->id,
            'age' => $request->age,
            'village' => $request->village,
            'sexe' => $request->sexe,
        ]);

        return redirect('/patients/create')->with('succes', 'Patient enregistré avec succès !');
    }

    public function index()
    {
        $patients = Patient::with('utilisateur')->get();
        return view('patients.index', ['patients' => $patients]);
    }

    public function show($id)
    {
        $patient = Patient::with(['utilisateur', 'dossierMedical', 'consultations.prescription'])
            ->findOrFail($id);

        return view('patients.show', ['patient' => $patient]);
    }

    public function edit($id)
    {
        $patient = Patient::with('utilisateur')->findOrFail($id);
        return view('patients.edit', ['patient' => $patient]);
    }

    public function update(Request $request, $id)
    {
        $patient = Patient::with('utilisateur')->findOrFail($id);

        $request->validate([
            'nom' => 'required|string',
            'prenom' => 'required|string',
            'telephone' => 'required|string|unique:utilisateurs,telephone,' . $patient->utilisateur->id,
            'age' => 'required|integer',
            'village' => 'required|string',
            'sexe' => 'required|string',
        ]);

        $patient->utilisateur->update([
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'telephone' => $request->telephone,
        ]);

        $patient->update([
            'age' => $request->age,
            'village' => $request->village,
            'sexe' => $request->sexe,
        ]);

        return redirect('/patients/' . $patient->id)->with('succes', 'Patient modifié avec succès.');
    }

    public function destroy($id)
    {
        $patient = Patient::findOrFail($id);
        $utilisateur = $patient->utilisateur;

        $patient->delete();
        if ($utilisateur) {
            $utilisateur->delete();
        }

        return redirect('/patients')->with('succes', 'Patient supprimé avec succès.');
    }

    public function exportExcel()
    {
        return \Maatwebsite\Excel\Facades\Excel::download(new \App\Exports\PatientsExport, 'patients.xlsx');
    }

    public function exportPdf($id)
    {
        $patient = Patient::with(['utilisateur', 'dossierMedical', 'consultations.prescription'])
            ->findOrFail($id);

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('patients.pdf', ['patient' => $patient]);

        return $pdf->download('dossier-' . $patient->utilisateur->nom . '.pdf');
    }
}