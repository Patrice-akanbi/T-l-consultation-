<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Administrateur extends Model
{
    protected $fillable = [
        'utilisateur_id',
        'district_gere',
    ];

    public function utilisateur()
    {
        return $this->belongsTo(Utilisateur::class);
    }
}