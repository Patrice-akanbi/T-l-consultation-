<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Utilisateur extends Authenticatable
{
    use Notifiable;

    protected $table = 'utilisateurs';

    protected $fillable = [
        'nom',
        'prenom',
        'telephone',
        'mot_de_passe',
        'type_utilisateur',
    ];

    protected $hidden = [
        'mot_de_passe',
    ];

    public function getAuthPassword()
    {
        return $this->mot_de_passe;
    }

    public function administrateur()
    {
        return $this->hasOne(Administrateur::class);
    }

    public function patient()
    {
        return $this->hasOne(Patient::class);
    }

    public function agentSante()
    {
        return $this->hasOne(AgentSante::class);
    }

    public function medecin()
    {
        return $this->hasOne(Medecin::class);
    }
}