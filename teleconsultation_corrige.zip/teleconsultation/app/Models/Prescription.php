<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Prescription extends Model
{
    protected $fillable = [
        'consultation_id',
        'medicaments',
        'posologie',
        'orientation',
    ];

    public function consultation()
    {
        return $this->belongsTo(Consultation::class);
    }
}