<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Medecin extends Model
{
    protected $fillable = [
        'utilisateur_id',
        'specialite',
        'matricule',
    ];

    public function utilisateur()
    {
        return $this->belongsTo(Utilisateur::class);
    }

    public function consultations()
    {
        return $this->hasMany(Consultation::class);
    }
}