<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DossierMedical extends Model
{
    protected $fillable = [
        'patient_id',
        'antecedent',
        'historique',
    ];

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }
}