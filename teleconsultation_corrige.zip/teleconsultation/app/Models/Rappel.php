<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Rappel extends Model
{
    protected $fillable = [
        'patient_id',
        'type',
        'date_envoi',
        'statut',
    ];

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }
}