<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AgentSante extends Model
{
    protected $table = 'agent_santes';

    protected $fillable = [
        'utilisateur_id',
        'village_affectation',
        'zone_couverte',
    ];

    public function utilisateur()
    {
        return $this->belongsTo(Utilisateur::class);
    }

    public function consultations()
    {
        return $this->hasMany(Consultation::class);
    }
}