<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConstanteSante extends Model
{
    protected $table = 'constante_santes';

    protected $fillable = [
        'consultation_id',
        'temperature',
        'tension',
        'symptomes',
        'poids',
    ];

    public function consultation()
    {
        return $this->belongsTo(Consultation::class);
    }
}
