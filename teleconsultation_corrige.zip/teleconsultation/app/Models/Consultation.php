<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Consultation extends Model
{
    protected $fillable = [
        'patient_id',
        'agent_sante_id',
        'medecin_id',
        'date',
        'heure',
        'mode',
        'statut',
    ];

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function agentSante()
    {
        return $this->belongsTo(AgentSante::class);
    }

    public function medecin()
    {
        return $this->belongsTo(Medecin::class);
    }

    public function constantesSante()
    {
        return $this->hasMany(ConstanteSante::class);
    }

    public function prescription()
    {
        return $this->hasOne(Prescription::class);
    }
}