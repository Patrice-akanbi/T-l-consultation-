<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Créer un rappel</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 40px auto; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 20px; padding: 10px 20px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        .succes { background: #d4edda; padding: 10px; margin-bottom: 15px; color: #155724; }
        a.retour { display: inline-block; margin-bottom: 15px; color: #1F4E79; text-decoration: none; }
    </style>
</head>
<body>
    <h1>Créer un rappel</h1>

    <a class="retour" href="/dashboard">&larr; Retour au tableau de bord</a>

    @if (session('succes'))
        <div class="succes">{{ session('succes') }}</div>
    @endif

    <form method="POST" action="/rappels">
        @csrf

        <label>Patient</label>
        <select name="patient_id">
            @foreach ($patients as $patient)
                <option value="{{ $patient->id }}">
                    {{ $patient->utilisateur->nom }} {{ $patient->utilisateur->prenom }}
                </option>
            @endforeach
        </select>

        <label>Type de rappel</label>
        <select name="type">
            <option value="rendez-vous">Rendez-vous de contrôle</option>
            <option value="prise_traitement">Prise de traitement</option>
        </select>

        <label>Date d'envoi</label>
        <input type="datetime-local" name="date_envoi">

        <button type="submit">Créer le rappel</button>
    </form>
</body>
</html>