<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des rappels</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background: #1F4E79; color: white; }
        tr:nth-child(even) { background: #f2f2f2; }
        a.bouton { display: inline-block; margin-top: 15px; padding: 8px 16px; background: #1F4E79; color: white; text-decoration: none; }
        .succes { background: #d4edda; padding: 10px; margin-bottom: 15px; color: #155724; }
        .statut { padding: 3px 8px; border-radius: 3px; font-size: 0.85em; }
        .non_envoye { background: #fff3cd; }
        .envoye { background: #d4edda; }
        .lu { background: #cce5ff; }
        select.statut-select { padding: 4px; }
        form.inline { display: inline; }
        .btn-delete { background: #c0392b; color: white; border: none; padding: 4px 10px; border-radius: 3px; cursor: pointer; font-size: 0.85em; margin-left: 6px; }
        a.retour { display: inline-block; margin-bottom: 15px; color: #1F4E79; text-decoration: none; }
    </style>
</head>
<body>
    <h1>Liste des rappels</h1>

    <a class="retour" href="/dashboard">&larr; Retour au tableau de bord</a>

    @if (session('succes'))
        <div class="succes">{{ session('succes') }}</div>
    @endif

    <a class="bouton" href="/rappels/create">+ Créer un rappel</a>

    <table>
        <thead>
            <tr>
                <th>Patient</th>
                <th>Type</th>
                <th>Date d'envoi</th>
                <th>Statut</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($rappels as $rappel)
                <tr>
                    <td>{{ $rappel->patient->utilisateur->nom }} {{ $rappel->patient->utilisateur->prenom }}</td>
                    <td>{{ $rappel->type }}</td>
                    <td>{{ $rappel->date_envoi }}</td>
                    <td>
                        <form class="inline" method="POST" action="/rappels/{{ $rappel->id }}/statut">
                            @csrf
                            @method('PATCH')
                            <select name="statut" class="statut-select" onchange="this.form.submit()">
                                <option value="non_envoye" {{ $rappel->statut === 'non_envoye' ? 'selected' : '' }}>Non envoyé</option>
                                <option value="envoye" {{ $rappel->statut === 'envoye' ? 'selected' : '' }}>Envoyé</option>
                                <option value="lu" {{ $rappel->statut === 'lu' ? 'selected' : '' }}>Lu</option>
                            </select>
                        </form>
                    </td>
                    <td>
                        <form class="inline" method="POST" action="/rappels/{{ $rappel->id }}" onsubmit="return confirm('Supprimer ce rappel ?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn-delete">Supprimer</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5">Aucun rappel créé.</td></tr>
            @endforelse
        </tbody>
    </table>
</body>
</html>