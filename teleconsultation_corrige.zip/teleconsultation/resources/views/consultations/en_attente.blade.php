<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Consultations en attente</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background: #1F4E79; color: white; }
        tr:nth-child(even) { background: #f2f2f2; }
        .succes { background: #d4edda; padding: 10px; margin-bottom: 15px; color: #155724; }
        button { padding: 6px 12px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        a.retour { display: inline-block; margin-bottom: 15px; color: #1F4E79; text-decoration: none; }
    </style>
</head>
<body>
    <h1>Consultations en attente</h1>

    <a class="retour" href="/dashboard">&larr; Retour au tableau de bord</a>

    @if (session('succes'))
        <div class="succes">{{ session('succes') }}</div>
    @endif

    <table>
        <thead>
            <tr>
                <th>Patient</th>
                <th>Date</th>
                <th>Symptômes</th>
                <th>Température</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($consultations as $consultation)
                <tr>
                    <td>{{ $consultation->patient->utilisateur->nom }} {{ $consultation->patient->utilisateur->prenom }}</td>
                    <td>{{ $consultation->date }}</td>
                    <td>{{ $consultation->constantesSante->first()->symptomes ?? '—' }}</td>
                    <td>{{ $consultation->constantesSante->first()->temperature ?? '—' }}</td>
                    <td>
                        <form method="POST" action="/consultations/{{ $consultation->id }}/prendre-en-charge">
                            @csrf
                            <button type="submit">Prendre en charge</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5">Aucune consultation en attente.</td></tr>
            @endforelse
        </tbody>
    </table>
</body>
</html>