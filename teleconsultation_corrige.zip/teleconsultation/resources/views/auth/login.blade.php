<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 400px; margin: 60px auto; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 20px; padding: 10px 20px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        .erreur { background: #f8d7da; padding: 10px; margin-bottom: 15px; color: #721c24; }
    </style>
</head>
<body>
    <h1>Connexion</h1>

    @if ($errors->any())
        <div class="erreur">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="/login">
        @csrf

        <label>Téléphone</label>
        <input type="text" name="telephone" value="{{ old('telephone') }}">

        <label>Mot de passe</label>
        <input type="password" name="mot_de_passe">

        <button type="submit">Se connecter</button>
    </form>
</body>
</html>