<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Émettre une prescription</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 40px auto; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 20px; padding: 10px 20px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        .succes { background: #d4edda; padding: 10px; margin-bottom: 15px; color: #155724; }
        .erreur { background: #f8d7da; padding: 10px; margin-bottom: 15px; color: #721c24; }
        a.retour { display: inline-block; margin-bottom: 15px; color: #1F4E79; text-decoration: none; }
    </style>
</head>
<body>
    <h1>Émettre une prescription</h1>

    <a class="retour" href="/dashboard">&larr; Retour au tableau de bord</a>

    @if (session('succes'))
        <div class="succes">{{ session('succes') }}</div>
    @endif

    @if ($errors->any())
        <div class="erreur">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="/prescriptions">
        @csrf

        <label>Consultation</label>
        <select name="consultation_id">
            @foreach ($consultations as $consultation)
                <option value="{{ $consultation->id }}">
                    {{ $consultation->patient->utilisateur->nom }} {{ $consultation->patient->utilisateur->prenom }}
                    — {{ $consultation->date }}
                </option>
            @endforeach
        </select>

        <label>Médicaments</label>
        <textarea name="medicaments" rows="2"></textarea>

        <label>Posologie</label>
        <textarea name="posologie" rows="2"></textarea>

        <label>Orientation (si besoin d'un centre de santé)</label>
        <textarea name="orientation" rows="2"></textarea>

        <button type="submit">Émettre la prescription</button>
    </form>
</body>
</html>