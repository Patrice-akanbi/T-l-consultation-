<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Enregistrer un patient</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 40px auto; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 20px; padding: 10px 20px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        .succes { background: #d4edda; padding: 10px; margin-bottom: 15px; color: #155724; }
        .erreur { background: #f8d7da; padding: 10px; margin-bottom: 15px; color: #721c24; }
        a.retour { display: inline-block; margin-bottom: 15px; color: #1F4E79; text-decoration: none; }
    </style>
</head>
<body>
    <h1>Enregistrer un patient</h1>

    <a class="retour" href="/dashboard">&larr; Retour au tableau de bord</a>

    @if (session('succes'))
        <div class="succes">{{ session('succes') }}</div>
    @endif

    @if ($errors->any())
        <div class="erreur">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="/patients">
        @csrf

        <label>Nom</label>
        <input type="text" name="nom" value="{{ old('nom') }}">

        <label>Prénom</label>
        <input type="text" name="prenom" value="{{ old('prenom') }}">

        <label>Téléphone</label>
        <input type="text" name="telephone" value="{{ old('telephone') }}">

        <label>Mot de passe</label>
        <input type="password" name="mot_de_passe">

        <label>Âge</label>
        <input type="number" name="age" value="{{ old('age') }}">

        <label>Village</label>
        <input type="text" name="village" value="{{ old('village') }}">

        <label>Sexe</label>
        <select name="sexe">
            <option value="M">Masculin</option>
            <option value="F">Féminin</option>
        </select>

        <button type="submit">Enregistrer</button>
    </form>
</body>
</html>