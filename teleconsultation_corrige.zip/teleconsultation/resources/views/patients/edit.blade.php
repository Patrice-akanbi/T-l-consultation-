<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier un patient</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 40px auto; }
        label { display: block; margin-top: 12px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box; }
        button { margin-top: 20px; padding: 10px 20px; background: #1F4E79; color: white; border: none; cursor: pointer; }
        .erreur { background: #f8d7da; padding: 10px; margin-bottom: 15px; color: #721c24; }
        a.retour { display: inline-block; margin-bottom: 15px; color: #1F4E79; text-decoration: none; }
    </style>
</head>
<body>
    <h1>Modifier le patient</h1>

    <a class="retour" href="/dashboard">&larr; Retour au tableau de bord</a>

    @if ($errors->any())
        <div class="erreur">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="/patients/{{ $patient->id }}">
        @csrf
        @method('PUT')

        <label>Nom</label>
        <input type="text" name="nom" value="{{ old('nom', $patient->utilisateur->nom) }}">

        <label>Prénom</label>
        <input type="text" name="prenom" value="{{ old('prenom', $patient->utilisateur->prenom) }}">

        <label>Téléphone</label>
        <input type="text" name="telephone" value="{{ old('telephone', $patient->utilisateur->telephone) }}">

        <label>Âge</label>
        <input type="number" name="age" value="{{ old('age', $patient->age) }}">

        <label>Village</label>
        <input type="text" name="village" value="{{ old('village', $patient->village) }}">

        <label>Sexe</label>
        <select name="sexe">
            <option value="M" {{ $patient->sexe === 'M' ? 'selected' : '' }}>Masculin</option>
            <option value="F" {{ $patient->sexe === 'F' ? 'selected' : '' }}>Féminin</option>
        </select>

        <button type="submit">Enregistrer les modifications</button>
    </form>
</body>
</html>