<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
        h1 { color: #1F4E79; font-size: 18px; }
        h2 { color: #1F4E79; font-size: 14px; margin-top: 20px; }
        .fiche td { padding: 4px 8px; }
        .fiche td.label { font-weight: bold; width: 150px; }
        table.historique { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table.historique th, table.historique td { border: 1px solid #ccc; padding: 6px; text-align: left; }
        table.historique th { background: #1F4E79; color: white; }
        .date { font-size: 10px; color: #666; margin-bottom: 15px; }
    </style>
</head>
<body>
    <h1>Dossier patient — {{ $patient->utilisateur->nom }} {{ $patient->utilisateur->prenom }}</h1>
    <div class="date">Généré le {{ now()->format('d/m/Y à H:i') }}</div>

    <table class="fiche">
        <tr><td class="label">Téléphone</td><td>{{ $patient->utilisateur->telephone }}</td></tr>
        <tr><td class="label">Âge</td><td>{{ $patient->age }} ans</td></tr>
        <tr><td class="label">Village</td><td>{{ $patient->village }}</td></tr>
        <tr><td class="label">Sexe</td><td>{{ $patient->sexe }}</td></tr>
    </table>

    @if ($patient->dossierMedical)
        <h2>Dossier médical</h2>
        <table class="fiche">
            <tr><td class="label">Antécédents</td><td>{{ $patient->dossierMedical->antecedent ?? 'Aucun renseigné' }}</td></tr>
            <tr><td class="label">Historique</td><td>{{ $patient->dossierMedical->historique ?? 'Aucun renseigné' }}</td></tr>
        </table>
    @endif

    <h2>Historique des consultations</h2>
    <table class="historique">
        <thead>
            <tr>
                <th>Date</th>
                <th>Mode</th>
                <th>Statut</th>
                <th>Prescription / Orientation</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($patient->consultations as $consultation)
                <tr>
                    <td>{{ $consultation->date }}</td>
                    <td>{{ $consultation->mode }}</td>
                    <td>{{ $consultation->statut }}</td>
                    <td>
                        @if ($consultation->prescription)
                            {{ $consultation->prescription->medicaments ?? $consultation->prescription->orientation ?? '—' }}
                        @else
                            En attente
                        @endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="4">Aucune consultation enregistrée.</td></tr>
            @endforelse
        </tbody>
    </table>
</body>
</html>