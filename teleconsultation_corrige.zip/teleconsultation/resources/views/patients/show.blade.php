<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dossier patient</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 750px; margin: 40px auto; }
        h1 { color: #1F4E79; }
        .fiche { background: #f2f2f2; padding: 15px; border-radius: 4px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background: #1F4E79; color: white; }
        .statut { padding: 3px 8px; border-radius: 3px; font-size: 0.85em; }
        .en_attente { background: #fff3cd; }
        .terminee { background: #d4edda; }
        a.retour { display: inline-block; margin-bottom: 15px; color: #1F4E79; }
        .actions { margin: 10px 0 20px; display: flex; gap: 10px; align-items: center; }
        .actions a, .actions button {
            display: inline-block; padding: 6px 14px; border-radius: 4px; text-decoration: none;
            font-size: 0.9em; border: none; cursor: pointer;
        }
        .btn-modifier { background: #1F4E79; color: white; }
        .btn-export { background: #2f855a; color: white; }
        .btn-delete { background: #c0392b; color: white; }
        .btn-delete-consult { background: #c0392b; color: white; border: none; padding: 4px 10px; border-radius: 3px; cursor: pointer; font-size: 0.85em; }
    </style>
</head>
<body>
    <a class="retour" href="/patients">&larr; Retour à la liste</a>
    <a class="retour" href="/dashboard" style="margin-left: 15px;">&larr; Retour au tableau de bord</a>

    <h1>{{ $patient->utilisateur->nom }} {{ $patient->utilisateur->prenom }}</h1>

    <div class="actions">
        <a class="btn-modifier" href="/patients/{{ $patient->id }}/edit">Modifier ce patient</a>
        <a class="btn-export" href="/patients/{{ $patient->id }}/export/pdf">Exporter en PDF</a>
        <form method="POST" action="/patients/{{ $patient->id }}" onsubmit="return confirm('Supprimer ce patient et toutes ses données liées ?');">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn-delete">Supprimer</button>
        </form>
    </div>

    <div class="fiche">
        <strong>Téléphone :</strong> {{ $patient->utilisateur->telephone }}<br>
        <strong>Âge :</strong> {{ $patient->age }} ans<br>
        <strong>Village :</strong> {{ $patient->village }}<br>
        <strong>Sexe :</strong> {{ $patient->sexe }}
    </div>

    @if ($patient->dossierMedical)
        <h2>Dossier médical</h2>
        <div class="fiche">
            <strong>Antécédents :</strong> {{ $patient->dossierMedical->antecedent ?? 'Aucun renseigné' }}<br>
            <strong>Historique :</strong> {{ $patient->dossierMedical->historique ?? 'Aucun renseigné' }}
        </div>
    @endif

    <h2>Historique des consultations</h2>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Mode</th>
                <th>Statut</th>
                <th>Prescription / Orientation</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($patient->consultations as $consultation)
                <tr>
                    <td>{{ $consultation->date }}</td>
                    <td>{{ $consultation->mode }}</td>
                    <td><span class="statut {{ $consultation->statut }}">{{ $consultation->statut }}</span></td>
                    <td>
                        @if ($consultation->prescription)
                            {{ $consultation->prescription->medicaments ?? $consultation->prescription->orientation ?? '—' }}
                        @else
                            En attente
                        @endif
                    </td>
                    <td>
                        <form method="POST" action="/consultations/{{ $consultation->id }}" onsubmit="return confirm('Supprimer cette consultation et ses données liées (constantes, prescription) ?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn-delete-consult">Supprimer</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5">Aucune consultation enregistrée.</td></tr>
            @endforelse
        </tbody>
    </table>
</body>
</html>