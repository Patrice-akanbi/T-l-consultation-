<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des patients</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background: #1F4E79; color: white; }
        tr:nth-child(even) { background: #f2f2f2; }
        a.bouton { display: inline-block; margin-top: 15px; padding: 8px 16px; background: #1F4E79; color: white; text-decoration: none; }
        a { color: #1F4E79; }
        form.delete-form { display: inline; }
        .btn-delete { background: #c0392b; color: white; border: none; padding: 4px 10px; border-radius: 3px; cursor: pointer; font-size: 0.85em; }
        a.retour { display: inline-block; margin-bottom: 15px; color: #1F4E79; text-decoration: none; }
    </style>
</head>
<body>
    <h1>Liste des patients</h1>

    <a class="retour" href="/dashboard">&larr; Retour au tableau de bord</a>

    <a class="bouton" href="/patients/create">+ Ajouter un patient</a>

    <a class="bouton" href="/patients/export/excel" style="background:#2f855a;">Exporter en Excel</a>

    <table>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Téléphone</th>
                <th>Âge</th>
                <th>Village</th>
                <th>Sexe</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($patients as $patient)
                <tr>
                    <td><a href="/patients/{{ $patient->id }}">{{ $patient->utilisateur->nom }}</a></td>
                    <td>{{ $patient->utilisateur->prenom }}</td>
                    <td>{{ $patient->utilisateur->telephone }}</td>
                    <td>{{ $patient->age }}</td>
                    <td>{{ $patient->village }}</td>
                    <td>{{ $patient->sexe }}</td>
                    <td>
                        <form class="delete-form" method="POST" action="/patients/{{ $patient->id }}" onsubmit="return confirm('Supprimer ce patient et toutes ses données liées ?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn-delete">Supprimer</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>