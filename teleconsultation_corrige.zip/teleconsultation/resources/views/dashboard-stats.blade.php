<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de bord</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1000px; margin: 40px auto; }
        h1 { color: #1F4E79; }
        .cartes { display: flex; flex-wrap: wrap; gap: 15px; margin-top: 20px; }
        .carte { background: #1F4E79; color: white; padding: 20px; border-radius: 6px; flex: 1; min-width: 150px; text-align: center; }
        .carte .chiffre { font-size: 2em; font-weight: bold; }
        .carte .label { font-size: 0.9em; margin-top: 5px; }
        .carte.attente { background: #b8860b; }
        .carte.cours { background: #2b6cb0; }
        .carte.terminee { background: #2f855a; }
        .graphiques { display: flex; flex-wrap: wrap; gap: 30px; margin-top: 40px; }
        .graphique-bloc { flex: 1; min-width: 320px; background: #f9f9f9; padding: 15px; border-radius: 6px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background: #1F4E79; color: white; }
        form.delete-form { display: inline; }
        .btn-delete { background: #c0392b; color: white; border: none; padding: 4px 10px; border-radius: 3px; cursor: pointer; font-size: 0.85em; }
    </style>
</head>
<body>
    <h1>Tableau de bord statistique</h1>

    <a href="/statistiques/export/pdf" style="display:inline-block;padding:8px 16px;background:#2f855a;color:white;text-decoration:none;border-radius:4px;">Exporter en PDF</a>

    <div class="cartes">
        <div class="carte">
            <div class="chiffre">{{ $stats['total_patients'] }}</div>
            <div class="label">Patients enregistrés</div>
        </div>
        <div class="carte">
            <div class="chiffre">{{ $stats['total_consultations'] }}</div>
            <div class="label">Consultations totales</div>
        </div>
        <div class="carte attente">
            <div class="chiffre">{{ $stats['consultations_en_attente'] }}</div>
            <div class="label">En attente</div>
        </div>
        <div class="carte cours">
            <div class="chiffre">{{ $stats['consultations_en_cours'] }}</div>
            <div class="label">En cours</div>
        </div>
        <div class="carte terminee">
            <div class="chiffre">{{ $stats['consultations_terminees'] }}</div>
            <div class="label">Terminées</div>
        </div>
        <div class="carte">
            <div class="chiffre">{{ $stats['total_agents'] }}</div>
            <div class="label">Agents de santé</div>
        </div>
        <div class="carte">
            <div class="chiffre">{{ $stats['total_medecins'] }}</div>
            <div class="label">Médecins</div>
        </div>
    </div>

    <div class="graphiques">
        <div class="graphique-bloc">
            <h3>Évolution des consultations (6 derniers mois)</h3>
            <canvas id="graphMois"></canvas>
        </div>
        <div class="graphique-bloc">
            <h3>Consultations par mode</h3>
            <canvas id="graphMode"></canvas>
        </div>
    </div>

    <h2>Répartition des patients par village</h2>
    <table>
        <thead>
            <tr>
                <th>Village</th>
                <th>Nombre de patients</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($parVillage as $ligne)
                <tr>
                    <td>{{ $ligne->village }}</td>
                    <td>{{ $ligne->total }}</td>
                </tr>
            @empty
                <tr><td colspan="2">Aucune donnée.</td></tr>
            @endforelse
        </tbody>
    </table>

    <script>
        const ctxMois = document.getElementById('graphMois');
        new Chart(ctxMois, {
            type: 'line',
            data: {
                labels: [@foreach($parMois as $m) '{{ $m->mois }}', @endforeach],
                datasets: [{
                    label: 'Consultations',
                    data: [@foreach($parMois as $m) {{ $m->total }}, @endforeach],
                    borderColor: '#1F4E79',
                    backgroundColor: 'rgba(31,78,121,0.15)',
                    tension: 0.3,
                    fill: true
                }]
            }
        });

        const ctxMode = document.getElementById('graphMode');
        new Chart(ctxMode, {
            type: 'doughnut',
            data: {
                labels: [@foreach($parMode as $m) '{{ ucfirst($m->mode) }}', @endforeach],
                datasets: [{
                    data: [@foreach($parMode as $m) {{ $m->total }}, @endforeach],
                    backgroundColor: ['#1F4E79', '#b8860b']
                }]
            }
        });
    </script>
</body>
</html>